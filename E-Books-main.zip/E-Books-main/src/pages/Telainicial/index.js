import { View, Text, TouchableOpacity, Image } from "react-native";
import styles from './styles';
import { TextInput } from "react-native-web";
import { useState } from "react";

export default function Login({ navigation }) {
    function acessarTelainicial() {
        navigation.navigate('Telainicial');
    }

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <View style={styles.headerLeft}>
                    <Text style={styles.headerText}>E - BOOKS</Text>
                    <Image source={require('./../../../imgs/livro.png')} style={styles.icon} />
                </View>
                <Image source={require('./../../../imgs/cachorro_perfil.png')} style={styles.profileImage} />
            </View>
            <TouchableOpacity style={styles.searchButton}>
                <Text style={styles.searchButtonText}>🔍</Text>
            </TouchableOpacity>
            <View style={styles.content}>
                <TouchableOpacity style={styles.genreButton}>
                    <Text style={styles.genreButtonText}>FANTASIA</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.addButton}>
                    <Text style={styles.addButtonText}>+</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
}
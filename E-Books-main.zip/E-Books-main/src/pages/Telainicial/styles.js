import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#2D3252',
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    header: {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        backgroundColor: '#494D7E', 
        paddingVertical: 40,
    },
    headerLeft: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    headerText: {
        color: '#FFF',
        fontSize: 20,
        fontWeight: 'bold',
        marginRight: 10,
    },
    icon: {
        width: 40,
        height: 40,
        marginRight: 10,
    },
    profileImage: {
        width: 40,
        height: 40,
        borderRadius: 20,
    },
    searchButton: {
        position: 'absolute',
        top: 25,
        right: 15,
        width: 30,
        height: 30,
        justifyContent: 'center',
        alignItems: 'center',
    },
    searchButtonText: {
        color: "#FFF",
        fontSize: 20,
    },
    content: {
        flex: 1,
        justifyContent: 'flex-start',
        alignItems: 'center',
        width: '100%',
    },
    genreButton: {
        backgroundColor: "#F9B17A",
        paddingHorizontal: 30,
        paddingVertical: 10,
        borderRadius: 8,
        marginBottom: 20,
        marginTop: 20,
    },
    genreButtonText: {
        color: "#000",
        fontSize: 18,
        fontWeight: 'bold',
    },
    addButton: {
        backgroundColor: "#F9B17A",
        width: 50,
        height: 50,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 20,
    },
    addButtonText: {
        color: "#000",
        fontSize: 30,
        fontWeight: 'bold',
    },
});